void osx_hide_native_mouse();
void osx_show_native_mouse();
